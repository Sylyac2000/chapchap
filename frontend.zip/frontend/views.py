from django.shortcuts import render
from .controller.LoginPage import LoginPageView

# Create your views here.

def accueil(request):

    return render(request, 'frontend/home.html')